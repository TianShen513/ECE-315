/**
 * @file ece315_leds.h
 * @author Joe Krachey (jkrachey@wisc.edu)
 * @brief 
 * @version 0.1
 * @date 2023-10-20
 * 
 * @copyright Copyright (c) 2023
 * 
 */
#ifndef __ECE315_LEDS_H__
#define __ECE315_LEDS_H__
#include "cyhal.h"
#include "cy_pdl.h"
#include "cybsp.h"
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>

#include "ece315_pins.h"

#define TICKS_MS_010 1000000
#define TICKS_MS_005 500000
#define TIMER_LED_TICKS_MS_250  12000000
#define TIMER_LED_TICKS_MS_50 2400000
#define TIMER_LED_TICKS_MS_45 2160000
#define TIMER_LED_TICKS_MS_40 1920000
#define TIMER_LED_TICKS_MS_35 1680000
#define TIMER_LED_TICKS_MS_5 240000
#define LED_ON              1
#define LED_OFF             0

extern volatile bool ALERT_LEDS_ON;
extern volatile bool ALERT_LEDS_OFF;
extern volatile bool ALERT_LEDS_50MS_ACTIVE;
extern volatile bool ALERT_LEDS_100MS_ACTIVE;
void ece315_leds_init(void);
void ece315_leds_all_on(void) ;
void ece315_leds_all_off(void) ;

#endif
