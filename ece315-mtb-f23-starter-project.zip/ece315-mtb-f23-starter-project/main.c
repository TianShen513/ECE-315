/**
 * @file main.c
 * @author Joe Krachey (jkrachey@wisc.edu)
 * @brief
 * @version 0.1
 * @date 2023-10-20
 *
 * @copyright Copyright (c) 2023
 *
 */

#include "drivers/ece315.h"

int main(void)
{
    bool buzzer_on = false;
    bool status_rx_upstream = false;
    bool status_rx_downstream = false;
    bool game_over = false;

    uint8_t upstream_msg[80];
    uint8_t downstream_msg[80];
    uint8_t currentLED = 0;
    uint8_t LEDindex = 0;

    /* Enable global interrupts */
    __enable_irq();

    /* Enable the button*/
    ece315_button_init();

    /* Enable LEDs */
    ece315_leds_init();

    // Turn LEDS off
    ece315_leds_all_off();

    /* Initialize the Buzzer to operate at 2.5KHz */
    ece315_buzzer_init(2500);

    for (;;)
    {
        if(game_over){
            
        }
         
        if (ALERT_BUTTON_PRESSED && (LEDindex == 1 || LEDindex == 2 || LEDindex == 3 || LEDindex == 4 || LEDindex == 5 || LEDindex == 6
        || LEDindex == 7 || LEDindex == 8))
        { 
            ALERT_BUTTON_PRESSED = false;
            // game over
            game_over = true;
            
        }
        
        if (ALERT_BUTTON_PRESSED && (LEDindex == 9 || LEDindex == 10 || LEDindex == 11 || LEDindex == 12))
        { 
            ALERT_BUTTON_PRESSED = false;
            ALERT_BUZZER_250MS_ACTIVE = false;
            ece315_buzzer_start();
            buzzer_on = true;
            
        }

        if(ALERT_BUZZER_250MS_ACTIVE){
            ALERT_BUZZER_250MS_ACTIVE = false;
            if(buzzer_on){
                ece315_buzzer_stop();
                buzzer_on = false;
            }
        }

        if( ALERT_LEDS_50MS_ACTIVE){
             ALERT_LEDS_50MS_ACTIVE = false;
            LEDindex = currentLED;
                    // Turn off the previous LED
            switch(currentLED) {
               case 1: 
                    cyhal_gpio_write(PIN_LED_R4, LED_OFF); break;
                case 2: 
                    cyhal_gpio_write(PIN_LED_R3, LED_OFF); break;
                case 3: 
                    cyhal_gpio_write(PIN_LED_R2, LED_OFF); break;
                case 4: 
                    cyhal_gpio_write(PIN_LED_R1, LED_OFF); break;
                case 5: 
                    cyhal_gpio_write(PIN_LED_Y4, LED_OFF); break;
                case 6: 
                    cyhal_gpio_write(PIN_LED_Y3, LED_OFF); break;
                case 7: 
                    cyhal_gpio_write(PIN_LED_Y2, LED_OFF); break;
                case 8: 
                    cyhal_gpio_write(PIN_LED_Y1, LED_OFF); break;
                case 9: 
                    cyhal_gpio_write(PIN_LED_G4, LED_OFF); break;
                case 10: 
                    cyhal_gpio_write(PIN_LED_G3, LED_OFF); break;
                case 11: 
                    cyhal_gpio_write(PIN_LED_G2, LED_OFF); break;
                case 12: 
                    cyhal_gpio_write(PIN_LED_G1, LED_OFF);break;
                default: break;
            }

            // Update the current LED
             currentLED = (currentLED % 12) + 1;
             printf("currentLED is %d \n\r", currentLED);
             LEDindex = currentLED;

            // Turn on the current LED
            switch(currentLED) {
                case 1: cyhal_gpio_write(PIN_LED_R4, LED_ON); break;
                case 2: cyhal_gpio_write(PIN_LED_R3, LED_ON); break;
                case 3: cyhal_gpio_write(PIN_LED_R2, LED_ON); break;
                case 4: cyhal_gpio_write(PIN_LED_R1, LED_ON); break;
                case 5: cyhal_gpio_write(PIN_LED_Y4, LED_ON); break;
                case 6: cyhal_gpio_write(PIN_LED_Y3, LED_ON); break;
                case 7: cyhal_gpio_write(PIN_LED_Y2, LED_ON); break;
                case 8: cyhal_gpio_write(PIN_LED_Y1, LED_ON); break;
                case 9: cyhal_gpio_write(PIN_LED_G4, LED_ON); break;
                case 10: cyhal_gpio_write(PIN_LED_G3, LED_ON); break;
                case 11: cyhal_gpio_write(PIN_LED_G2, LED_ON); break;
                case 12: cyhal_gpio_write(PIN_LED_G1, LED_ON); break;
                default: break;
            }

        }


    }
}

/* [] END OF FILE */
